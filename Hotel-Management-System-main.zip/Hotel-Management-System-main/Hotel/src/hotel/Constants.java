/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel;


public class Constants {
      public static final String GUEST_RECORD_LIST_FILE_NAME = "GuestReservations.txt";
    public static final String RECORD_LIST_HEADER = "Name, Surname, Identification Number, Address, Phone Number, Room Type, Room No, Night Stay, Room Price ( $ )";
    public static final String  CHECK_IN_CHECK_OUT_LIST_FILE_NAME = "CheckIn-CheckOutRecords.txt";
}
